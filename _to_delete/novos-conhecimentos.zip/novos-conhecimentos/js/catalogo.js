/* =========================================================================
   catalogo.js — Banco de conceitos do Novos Conhecimentos
   -------------------------------------------------------------------------
   Este arquivo contém APENAS os termos: é o reservatório de onde os
   documentos de estudo são produzidos. O app só sorteia entre conceitos
   que já possuem documento escrito (verificado em CONTEUDOS, em conteudos.js).

   Campos:
     id           slug estável (não renomear depois de publicado)
     termo        nome do conceito como aparece na tela
     area         grande área do conhecimento
     dificuldade  1 a 5 — carga de pré-requisitos, não "importância"
     gancho       uma linha sobre por que vale a pena
   ========================================================================= */

const CATALOGO = [

  /* ── Matemática ───────────────────────────────────────────────────── */
  { id:"fourier", termo:"Transformada de Fourier", area:"Matemática", dificuldade:4, gancho:"Qualquer sinal complicado é uma soma de ondas simples — a ideia que sustenta MP3, MRI e Wi-Fi." },
  { id:"bayes", termo:"Teorema de Bayes", area:"Matemática", dificuldade:3, gancho:"Uma fórmula de uma linha que descreve como uma crença deveria mudar diante de evidência." },
  { id:"cantor-infinitos", termo:"Cardinalidade e os infinitos de Cantor", area:"Matemática", dificuldade:3, gancho:"Existem infinitos maiores que outros infinitos, e dá para provar isso em meia página." },
  { id:"godel", termo:"Teoremas da incompletude de Gödel", area:"Matemática", dificuldade:4, gancho:"Todo sistema formal suficientemente rico contém verdades que ele não consegue provar." },
  { id:"topologia-basica", termo:"Topologia e invariantes", area:"Matemática", dificuldade:4, gancho:"Por que a xícara e a rosquinha são o mesmo objeto — e por que isso é útil." },
  { id:"caos-deterministico", termo:"Caos determinístico", area:"Matemática", dificuldade:3, gancho:"Sistemas totalmente previsíveis em princípio e absolutamente imprevisíveis na prática." },
  { id:"fractais", termo:"Dimensão fractal", area:"Matemática", dificuldade:3, gancho:"Quanto mede a costa da Grã-Bretanha? Depende do tamanho da sua régua." },
  { id:"teoria-jogos", termo:"Equilíbrio de Nash", area:"Matemática", dificuldade:3, gancho:"O ponto em que ninguém melhora mudando sozinho — e por que isso pode ser péssimo para todos." },
  { id:"grafos", termo:"Teoria dos grafos e as pontes de Königsberg", area:"Matemática", dificuldade:2, gancho:"Um passeio impossível numa cidade prussiana fundou a matemática das redes." },
  { id:"numeros-complexos", termo:"Números complexos e a identidade de Euler", area:"Matemática", dificuldade:3, gancho:"A raiz de menos um deixou de ser truque e virou a linguagem natural da rotação." },
  { id:"prob-condicional", termo:"Falácia do promotor e probabilidade condicional", area:"Matemática", dificuldade:2, gancho:"Um erro de inversão de probabilidades já condenou pessoas inocentes em tribunais reais." },
  { id:"otimizacao-convexa", termo:"Convexidade e otimização", area:"Matemática", dificuldade:4, gancho:"A fronteira real entre problemas que sabemos resolver e os que só sabemos aproximar." },
  { id:"algebra-linear-svd", termo:"Decomposição em valores singulares", area:"Matemática", dificuldade:4, gancho:"O canivete suíço que aparece em compressão de imagem, recomendação e redução de dimensionalidade." },
  { id:"secao-aurea", termo:"Razão áurea: matemática e mito", area:"Matemática", dificuldade:2, gancho:"Uma proporção real na botânica e uma lenda estética que quase nada sustenta." },
  { id:"problema-monty-hall", termo:"Problema de Monty Hall", area:"Matemática", dificuldade:2, gancho:"A resposta correta parece errada até para matemáticos profissionais — e há motivo cognitivo para isso." },

  /* ── Física ───────────────────────────────────────────────────────── */
  { id:"quatro-forcas", termo:"As quatro interações fundamentais", area:"Física", dificuldade:3, gancho:"Tudo que acontece no universo é mediado por quatro conversas diferentes entre partículas." },
  { id:"entropia", termo:"Entropia e a segunda lei da termodinâmica", area:"Física", dificuldade:3, gancho:"A única lei da física que sabe distinguir passado de futuro." },
  { id:"relatividade-restrita", termo:"Relatividade restrita e dilatação temporal", area:"Física", dificuldade:4, gancho:"Manter a velocidade da luz constante custa caro: o tempo e o espaço têm que ceder." },
  { id:"emaranhamento", termo:"Emaranhamento quântico e desigualdades de Bell", area:"Física", dificuldade:4, gancho:"Um experimento decidiu empiricamente uma disputa que Einstein achava ser só filosófica." },
  { id:"efeito-casimir", termo:"Efeito Casimir e o vácuo quântico", area:"Física", dificuldade:4, gancho:"Duas placas metálicas no vácuo se atraem — porque o nada não é nada." },
  { id:"supercondutividade", termo:"Supercondutividade", area:"Física", dificuldade:4, gancho:"Resistência elétrica exatamente zero, e um mecanismo que levou 46 anos para ser explicado." },
  { id:"buracos-negros-termo", termo:"Termodinâmica de buracos negros", area:"Física", dificuldade:5, gancho:"Buracos negros têm temperatura e entropia — e isso conecta gravidade, quântica e informação." },
  { id:"escalas-alometria", termo:"Leis de escala e alometria", area:"Física", dificuldade:3, gancho:"Por que não existem formigas do tamanho de elefantes: a geometria proíbe." },
  { id:"ressonancia", termo:"Ressonância", area:"Física", dificuldade:2, gancho:"Empurrar no ritmo certo derruba pontes e afina rádios — o mesmo fenômeno." },
  { id:"materia-escura", termo:"Matéria escura: evidências e alternativas", area:"Física", dificuldade:4, gancho:"85% da matéria do universo é algo que nunca detectamos diretamente. Ou nossa gravidade está errada." },
  { id:"laser", termo:"Como funciona um laser", area:"Física", dificuldade:3, gancho:"Emissão estimulada: uma previsão de Einstein de 1917 que virou leitor de código de barras." },
  { id:"efeito-doppler", termo:"Efeito Doppler e expansão do universo", area:"Física", dificuldade:2, gancho:"O mesmo motivo pelo qual a ambulância muda de tom revelou que o universo está se expandindo." },
  { id:"principio-minima-acao", termo:"Princípio da mínima ação", area:"Física", dificuldade:4, gancho:"A natureza parece escolher o caminho que otimiza uma quantidade abstrata. Ninguém sabe bem por quê." },
  { id:"tempo-seta", termo:"A seta do tempo", area:"Física", dificuldade:4, gancho:"As leis fundamentais não distinguem passado e futuro. Então por que nós distinguimos?" },
  { id:"plasma", termo:"Plasma: o quarto estado da matéria", area:"Física", dificuldade:2, gancho:"99% da matéria visível do universo está num estado que quase não existe na superfície da Terra." },

  /* ── Química ──────────────────────────────────────────────────────── */
  { id:"catalise", termo:"Catálise e energia de ativação", area:"Química", dificuldade:2, gancho:"Como acelerar uma reação em bilhões de vezes sem consumir nada no processo." },
  { id:"quiralidade", termo:"Quiralidade molecular", area:"Química", dificuldade:3, gancho:"Duas moléculas idênticas como mão esquerda e direita: uma cura, a outra causou a talidomida." },
  { id:"ligacao-hidrogenio", termo:"Ligação de hidrogênio e as anomalias da água", area:"Química", dificuldade:2, gancho:"O gelo flutuar é uma anomalia física — e a vida na Terra depende dela." },
  { id:"haber-bosch", termo:"Processo Haber-Bosch", area:"Química", dificuldade:3, gancho:"Metade do nitrogênio do seu corpo passou por uma fábrica. Sustenta ~4 bilhões de pessoas." },
  { id:"tabela-periodica", termo:"A lógica da tabela periódica", area:"Química", dificuldade:2, gancho:"Não é uma lista: é um mapa da mecânica quântica dos elétrons disfarçado de tabela." },
  { id:"polimeros", termo:"Polímeros e a origem dos plásticos", area:"Química", dificuldade:2, gancho:"Moléculas gigantes que criaram uma civilização material e um problema geológico." },
  { id:"eletroquimica-baterias", termo:"Eletroquímica das baterias de íon-lítio", area:"Química", dificuldade:3, gancho:"Toda a transição energética depende de mover íons entre duas camadas de material." },
  { id:"maillard", termo:"Reação de Maillard", area:"Química", dificuldade:2, gancho:"Praticamente tudo o que consideramos 'gostoso' e dourado vem de uma única família de reações." },
  { id:"ph-tampao", termo:"pH e sistemas-tampão", area:"Química", dificuldade:2, gancho:"Seu sangue varia menos de 0,1 de pH ou você morre — e a química que garante isso é elegante." },
  { id:"quimica-verde", termo:"Química verde e economia atômica", area:"Química", dificuldade:2, gancho:"Reformular a pergunta industrial: não 'quanto rende?', mas 'quanto vira lixo?'" },

  /* ── Biologia ─────────────────────────────────────────────────────── */
  { id:"endossimbiose", termo:"Teoria endossimbiótica", area:"Biologia", dificuldade:2, gancho:"Suas mitocôndrias já foram bactérias livres. A ideia foi rejeitada por 15 revistas." },
  { id:"deriva-genetica", termo:"Deriva genética e efeito fundador", area:"Biologia", dificuldade:3, gancho:"Evolução também acontece por puro acaso — e em populações pequenas o acaso domina." },
  { id:"altruismo-hamilton", termo:"Seleção de parentesco e a regra de Hamilton", area:"Biologia", dificuldade:3, gancho:"Uma desigualdade de três termos que explica por que abelhas operárias abrem mão de reproduzir." },
  { id:"relogio-circadiano", termo:"Relógio circadiano molecular", area:"Biologia", dificuldade:3, gancho:"Cada célula do seu corpo tem um oscilador químico de 24 horas. Nobel de 2017." },
  { id:"microbioma", termo:"Microbioma intestinal: o que se sabe de fato", area:"Biologia", dificuldade:3, gancho:"Área com resultados reais e um dos maiores excessos de extrapolação da biologia atual." },
  { id:"apoptose", termo:"Apoptose: morte celular programada", area:"Biologia", dificuldade:3, gancho:"Você produz e destrói bilhões de células por dia de forma deliberada e organizada." },
  { id:"crispr", termo:"CRISPR-Cas9", area:"Biologia", dificuldade:3, gancho:"Um sistema imune bacteriano virou a ferramenta de edição genética mais acessível da história." },
  { id:"convergencia-evolutiva", termo:"Convergência evolutiva", area:"Biologia", dificuldade:2, gancho:"O olho tipo câmera surgiu independentemente pelo menos duas vezes. Isso diz algo sobre restrições." },
  { id:"neuroplasticidade", termo:"Neuroplasticidade: alcance e limites", area:"Biologia", dificuldade:3, gancho:"O cérebro muda com o uso — mas muito menos e mais devagar do que a divulgação sugere." },
  { id:"fotossintese-c4", termo:"Fotossíntese C3, C4 e CAM", area:"Biologia", dificuldade:3, gancho:"Três soluções de engenharia diferentes para o mesmo problema: capturar carbono sem perder água." },
  { id:"virus-definicao", termo:"Vírus são vivos? O problema da definição de vida", area:"Biologia", dificuldade:2, gancho:"Uma pergunta de fronteira que revela que 'vida' talvez não seja uma categoria natural." },
  { id:"telomeros", termo:"Telômeros e senescência celular", area:"Biologia", dificuldade:3, gancho:"Um contador molecular de divisões — e a razão pela qual células normais não são imortais." },

  /* ── Neurociência e Psicologia ────────────────────────────────────── */
  { id:"efeito-teste", termo:"Efeito de teste e prática de recuperação", area:"Psicologia", dificuldade:2, gancho:"Estudar relendo produz confiança; estudar se testando produz memória. Não é a mesma coisa." },
  { id:"memoria-trabalho", termo:"Memória de trabalho e carga cognitiva", area:"Psicologia", dificuldade:2, gancho:"O gargalo de ~4 itens que limita tudo que você consegue pensar simultaneamente." },
  { id:"dissonancia-cognitiva", termo:"Dissonância cognitiva", area:"Psicologia", dificuldade:2, gancho:"Mudamos nossas crenças para justificar o que já fizemos, não o contrário." },
  { id:"vies-confirmacao", termo:"Viés de confirmação", area:"Psicologia", dificuldade:2, gancho:"O viés mais bem documentado da psicologia — e o mais difícil de perceber em si mesmo." },
  { id:"crise-replicacao", termo:"Crise de replicação na psicologia", area:"Psicologia", dificuldade:3, gancho:"Metade dos achados clássicos não se sustentou. Como uma ciência descobre que estava errada." },
  { id:"heuristicas-kahneman", termo:"Heurísticas e vieses (Kahneman e Tversky)", area:"Psicologia", dificuldade:2, gancho:"Atalhos mentais que funcionam bem quase sempre e falham de formas previsíveis." },
  { id:"efeito-placebo", termo:"Efeito placebo e nocebo", area:"Psicologia", dificuldade:3, gancho:"Expectativa produz efeitos fisiológicos mensuráveis — e também confunde ensaios clínicos inteiros." },
  { id:"atencao-seletiva", termo:"Atenção seletiva e cegueira desatencional", area:"Psicologia", dificuldade:2, gancho:"Você não vê o gorila. Ver exige atenção, e atenção é um recurso escasso." },
  { id:"neuronios-espelho", termo:"Neurônios-espelho: achado e exagero", area:"Neurociência", dificuldade:3, gancho:"Estudo de caso de como uma descoberta real vira explicação universal sem evidência." },
  { id:"consolidacao-sono", termo:"Sono e consolidação de memória", area:"Neurociência", dificuldade:3, gancho:"Dormir não é pausa do aprendizado: é parte do processamento." },
  { id:"dor-cronica", termo:"Dor crônica como fenômeno do sistema nervoso", area:"Neurociência", dificuldade:3, gancho:"Dor sem lesão é real e mensurável — e isso muda completamente o tratamento." },
  { id:"predicao-cerebral", termo:"Cérebro preditivo e codificação preditiva", area:"Neurociência", dificuldade:4, gancho:"Talvez percepção seja alucinação controlada por erro de previsão. Teoria ambiciosa e disputada." },

  /* ── Filosofia ────────────────────────────────────────────────────── */
  { id:"hegel-fenomenologia", termo:"Fenomenologia do espírito e dialética em Hegel", area:"Filosofia", dificuldade:5, gancho:"O livro mais difícil da filosofia moderna, e a ideia de que a verdade tem história." },
  { id:"problema-inducao", termo:"O problema da indução (Hume)", area:"Filosofia", dificuldade:3, gancho:"Nenhuma quantidade de observações justifica logicamente uma previsão. A ciência convive com isso." },
  { id:"falseabilidade", termo:"Falseabilidade e demarcação (Popper)", area:"Filosofia", dificuldade:2, gancho:"O critério mais citado para separar ciência de não-ciência — e suas falhas conhecidas." },
  { id:"paradigmas-kuhn", termo:"Paradigmas e revoluções científicas (Kuhn)", area:"Filosofia", dificuldade:3, gancho:"Ciência não avança acumulando: ela troca de mapa e não consegue traduzir entre eles." },
  { id:"utilitarismo", termo:"Utilitarismo e suas objeções", area:"Filosofia", dificuldade:2, gancho:"Maximizar bem-estar agregado parece óbvio até você levar a sério as consequências." },
  { id:"imperativo-categorico", termo:"Imperativo categórico (Kant)", area:"Filosofia", dificuldade:3, gancho:"Moral derivada da estrutura da razão, não das consequências. Rigoroso e desconfortável." },
  { id:"quarto-chines", termo:"Quarto chinês e compreensão em máquinas", area:"Filosofia", dificuldade:2, gancho:"Um argumento de 1980 que voltou a ser o centro do debate sobre IA." },
  { id:"problema-dificil", termo:"O problema difícil da consciência", area:"Filosofia", dificuldade:3, gancho:"Por que processamento de informação é acompanhado de experiência subjetiva?" },
  { id:"experimento-mental-navio", termo:"Navio de Teseu e identidade ao longo do tempo", area:"Filosofia", dificuldade:2, gancho:"Se todas as peças são trocadas, ainda é o mesmo objeto? Aplica-se a você também." },
  { id:"veu-ignorancia", termo:"Véu de ignorância (Rawls)", area:"Filosofia", dificuldade:2, gancho:"Que sociedade você escolheria sem saber qual lugar ocuparia nela?" },
  { id:"eterno-retorno", termo:"Eterno retorno e niilismo em Nietzsche", area:"Filosofia", dificuldade:3, gancho:"Um teste existencial: você viveria essa mesma vida infinitas vezes?" },
  { id:"linguagem-wittgenstein", termo:"Jogos de linguagem no segundo Wittgenstein", area:"Filosofia", dificuldade:4, gancho:"Significado não é referência: é uso. Um filósofo que refutou o próprio livro anterior." },
  { id:"fenomenologia-husserl", termo:"Intencionalidade e epoché em Husserl", area:"Filosofia", dificuldade:4, gancho:"Suspender a pergunta sobre o mundo real para descrever como ele aparece." },
  { id:"existencialismo-sartre", termo:"Existência precede a essência (Sartre)", area:"Filosofia", dificuldade:2, gancho:"Liberdade radical como condenação, não como privilégio." },
  { id:"etica-virtude", termo:"Ética das virtudes e eudaimonia", area:"Filosofia", dificuldade:2, gancho:"A pergunta grega não era 'o que devo fazer?', mas 'que tipo de pessoa devo ser?'" },
  { id:"paradoxo-sorites", termo:"Paradoxo sorites e vagueza", area:"Filosofia", dificuldade:2, gancho:"Um grão não faz um monte. Nem dois. Onde exatamente começa o monte?" },
  { id:"argumento-ontologico", termo:"Argumento ontológico e suas refutações", area:"Filosofia", dificuldade:3, gancho:"Uma tentativa de provar Deus só pela lógica — e a crítica de Kant sobre existência como predicado." },
  { id:"escola-frankfurt", termo:"Indústria cultural e a Escola de Frankfurt", area:"Filosofia", dificuldade:3, gancho:"Uma crítica de 1944 à cultura de massa que envelheceu de forma perturbadora." },

  /* ── Economia ─────────────────────────────────────────────────────── */
  { id:"vantagem-comparativa", termo:"Vantagem comparativa", area:"Economia", dificuldade:3, gancho:"Comércio compensa mesmo quando um lado é pior em tudo. Contraintuitivo e demonstrável." },
  { id:"externalidades", termo:"Externalidades e o teorema de Coase", area:"Economia", dificuldade:3, gancho:"Quando o preço mente sobre o custo real, e o que fazer quanto a isso." },
  { id:"assimetria-informacao", termo:"Assimetria de informação e o mercado de limões", area:"Economia", dificuldade:2, gancho:"Por que carros usados bons somem do mercado. Rendeu um Nobel." },
  { id:"custo-oportunidade", termo:"Custo de oportunidade e custos afundados", area:"Economia", dificuldade:2, gancho:"Os dois erros de raciocínio econômico mais comuns na vida cotidiana." },
  { id:"inflacao-mecanismos", termo:"Inflação: mecanismos e disputas", area:"Economia", dificuldade:3, gancho:"Um fenômeno com pelo menos três explicações concorrentes ainda hoje." },
  { id:"curva-laffer", termo:"Curva de Laffer: teoria e evidência", area:"Economia", dificuldade:2, gancho:"Uma ideia matematicamente trivial que virou bandeira política sem base empírica clara." },
  { id:"tragedia-comuns", termo:"Tragédia dos comuns e a crítica de Ostrom", area:"Economia", dificuldade:3, gancho:"O modelo clássico previa colapso. Ostrom foi a campo e encontrou o contrário." },
  { id:"bolhas-financeiras", termo:"Bolhas especulativas", area:"Economia", dificuldade:3, gancho:"Comportamento racional individual produzindo insanidade coletiva, repetidamente, há 400 anos." },
  { id:"gini-desigualdade", termo:"Medidas de desigualdade: Gini e alternativas", area:"Economia", dificuldade:2, gancho:"Um único número para resumir a distribuição de renda — e tudo que ele esconde." },
  { id:"moeda-fiduciaria", termo:"O que dá valor ao dinheiro", area:"Economia", dificuldade:2, gancho:"Papel sem lastro que funciona porque todo mundo acredita que funciona. Isso é frágil?" },
  { id:"paradoxo-produtividade", termo:"Paradoxo da produtividade de Solow", area:"Economia", dificuldade:3, gancho:"Computadores estão em toda parte, menos nas estatísticas de produtividade." },
  { id:"economia-comportamental", termo:"Economia comportamental e nudges", area:"Economia", dificuldade:2, gancho:"Substituir o agente racional por gente real — e a discussão sobre paternalismo que veio junto." },
  { id:"salario-minimo-debate", termo:"Salário mínimo: o debate empírico", area:"Economia", dificuldade:3, gancho:"Caso exemplar de como dados naturais mudaram um consenso teórico de décadas." },
  { id:"renda-basica", termo:"Renda básica universal: evidência dos experimentos", area:"Economia", dificuldade:3, gancho:"Vários testes de campo já foram feitos. O que eles realmente mostraram?" },
  { id:"teoria-firma", termo:"Por que existem empresas (Coase)", area:"Economia", dificuldade:3, gancho:"Se o mercado é eficiente, por que tanta atividade acontece dentro de hierarquias?" },

  /* ── Ciência Política e Direito ───────────────────────────────────── */
  { id:"teorema-arrow", termo:"Teorema da impossibilidade de Arrow", area:"Ciência Política", dificuldade:4, gancho:"Nenhum sistema eleitoral satisfaz simultaneamente critérios razoáveis de justiça. Prova matemática." },
  { id:"sistemas-eleitorais", termo:"Sistemas eleitorais e a lei de Duverger", area:"Ciência Política", dificuldade:2, gancho:"A regra de contagem de votos molda o número de partidos que um país tem." },
  { id:"separacao-poderes", termo:"Separação de poderes: origem e tensões", area:"Ciência Política", dificuldade:2, gancho:"Uma arquitetura institucional projetada para funcionar mal de propósito." },
  { id:"contrato-social", termo:"Contrato social: Hobbes, Locke e Rousseau", area:"Ciência Política", dificuldade:3, gancho:"Três respostas incompatíveis para a mesma pergunta sobre a origem da autoridade." },
  { id:"gerrymandering", termo:"Gerrymandering e geometria eleitoral", area:"Ciência Política", dificuldade:2, gancho:"Como desenhar mapas para vencer eleições sem ganhar mais votos." },
  { id:"acao-coletiva", termo:"Lógica da ação coletiva (Olson)", area:"Ciência Política", dificuldade:3, gancho:"Grupos pequenos e concentrados costumam vencer maiorias difusas. Explica muita política." },
  { id:"estado-de-direito", termo:"Estado de direito e legalidade", area:"Direito", dificuldade:2, gancho:"A diferença entre governar por leis e governar com leis." },
  { id:"presuncao-inocencia", termo:"Ônus da prova e presunção de inocência", area:"Direito", dificuldade:2, gancho:"Uma assimetria deliberada: o sistema aceita errar mais numa direção que na outra." },
  { id:"common-law-civil", termo:"Common law e civil law", area:"Direito", dificuldade:2, gancho:"Duas tradições jurídicas com concepções opostas sobre de onde vem o direito." },
  { id:"propriedade-intelectual", termo:"Propriedade intelectual: justificativas e críticas", area:"Direito", dificuldade:3, gancho:"Um monopólio temporário concedido pelo Estado — a justificativa é utilitária, não natural." },
  { id:"federalismo", termo:"Federalismo e desenho institucional", area:"Ciência Política", dificuldade:2, gancho:"Como distribuir poder no espaço sem dissolver o país nem sufocar a diversidade." },
  { id:"populismo", termo:"Populismo como conceito analítico", area:"Ciência Política", dificuldade:3, gancho:"Um termo usado como xingamento que tem definição técnica precisa e mensurável." },

  /* ── Sociologia e Antropologia ────────────────────────────────────── */
  { id:"capital-cultural", termo:"Capital cultural e distinção (Bourdieu)", area:"Sociologia", dificuldade:3, gancho:"Gosto não é pessoal: é posição social convertida em preferência estética." },
  { id:"anomia", termo:"Anomia e suicídio em Durkheim", area:"Sociologia", dificuldade:3, gancho:"O primeiro grande estudo a mostrar que um ato íntimo tem estrutura social." },
  { id:"dadiva-mauss", termo:"A dádiva e a obrigação de retribuir (Mauss)", area:"Antropologia", dificuldade:3, gancho:"Não existe presente gratuito. Toda troca cria dívida — e vínculo." },
  { id:"lacos-fracos", termo:"A força dos laços fracos (Granovetter)", area:"Sociologia", dificuldade:2, gancho:"Empregos vêm de conhecidos distantes, não de amigos próximos. E há razão estrutural." },
  { id:"profecia-autorrealizavel", termo:"Profecia autorrealizável", area:"Sociologia", dificuldade:2, gancho:"Uma crença falsa que se torna verdadeira só por ser acreditada." },
  { id:"panoptico", termo:"Panóptico e sociedade disciplinar (Foucault)", area:"Sociologia", dificuldade:3, gancho:"O poder mais eficiente não pune: faz você se vigiar sozinho." },
  { id:"etnografia", termo:"Método etnográfico e observação participante", area:"Antropologia", dificuldade:2, gancho:"Como transformar convivência prolongada em conhecimento com validade." },
  { id:"tabu-pureza", termo:"Pureza e perigo (Mary Douglas)", area:"Antropologia", dificuldade:3, gancho:"Sujeira é matéria fora do lugar. Toda classificação produz seu próprio nojo." },
  { id:"individualismo-metodologico", termo:"Individualismo metodológico versus holismo", area:"Sociologia", dificuldade:3, gancho:"Explicar o social pelos indivíduos ou o indivíduo pelo social? A briga fundadora da área." },
  { id:"modernidade-liquida", termo:"Modernidade líquida (Bauman)", area:"Sociologia", dificuldade:2, gancho:"Um diagnóstico influente da instabilidade contemporânea — e as críticas de que é impressionista." },

  /* ── História ─────────────────────────────────────────────────────── */
  { id:"peste-negra", termo:"Peste Negra e reorganização econômica", area:"História", dificuldade:2, gancho:"Um terço da Europa morreu e os salários dos sobreviventes dispararam. As consequências duraram séculos." },
  { id:"revolucao-neolitica", termo:"Revolução neolítica", area:"História", dificuldade:2, gancho:"A agricultura piorou a saúde e a jornada de trabalho humana. Por que ela venceu mesmo assim?" },
  { id:"imprensa-gutenberg", termo:"Prensa de tipos móveis e suas consequências", area:"História", dificuldade:2, gancho:"A tecnologia que baixou o custo da cópia e, de quebra, produziu a Reforma." },
  { id:"revolucao-industrial-porque", termo:"Por que a Revolução Industrial aconteceu na Inglaterra", area:"História", dificuldade:3, gancho:"Uma das perguntas mais disputadas da história econômica, com pelo menos cinco respostas rivais." },
  { id:"trocas-colombianas", termo:"Intercâmbio colombiano", area:"História", dificuldade:2, gancho:"Batata, milho e doenças redesenharam a demografia de quatro continentes." },
  { id:"iluminismo", termo:"Iluminismo: programa e contradições", area:"História", dificuldade:3, gancho:"Razão universal proclamada por sociedades escravistas. A tensão não é acidental." },
  { id:"guerra-fria-dissuasao", termo:"Dissuasão nuclear e destruição mútua assegurada", area:"História", dificuldade:3, gancho:"Uma doutrina que dependia de tornar crível uma ameaça suicida." },
  { id:"bretton-woods", termo:"Bretton Woods e a ordem monetária do pós-guerra", area:"História", dificuldade:3, gancho:"Como 44 países desenharam o sistema financeiro global num hotel em New Hampshire." },
  { id:"descolonizacao", termo:"Descolonização e fronteiras herdadas", area:"História", dificuldade:3, gancho:"Estados desenhados por réguas europeias e os conflitos que persistiram por 60 anos." },
  { id:"historiografia-annales", termo:"Escola dos Annales e a longa duração", area:"História", dificuldade:3, gancho:"Trocar reis e batalhas por clima, comércio e hábitos alimentares como objeto da história." },
  { id:"revolucao-cientifica", termo:"Revolução científica do século XVII", area:"História", dificuldade:3, gancho:"O momento em que experimento e matemática viraram a autoridade sobre a natureza." },
  { id:"seda-rotas", termo:"Rotas da seda e a economia eurasiática", area:"História", dificuldade:2, gancho:"Uma rede comercial de 1.500 anos que moveu tecnologia, religião e epidemias." },
  { id:"memoria-historica", termo:"Memória, monumento e história pública", area:"História", dificuldade:2, gancho:"Quem decide o que é lembrado em praça pública, e por que isso volta a ser disputado." },
  { id:"pequena-era-gelo", termo:"Pequena Era do Gelo e crise do século XVII", area:"História", dificuldade:3, gancho:"Um resfriamento de poucos graus coincidindo com colapsos políticos em três continentes." },

  /* ── Linguística ──────────────────────────────────────────────────── */
  { id:"sapir-whorf", termo:"Relatividade linguística (hipótese Sapir-Whorf)", area:"Linguística", dificuldade:3, gancho:"A língua molda o pensamento? Versão forte refutada, versão fraca com evidência real." },
  { id:"gramatica-universal", termo:"Gramática universal e o debate inatista", area:"Linguística", dificuldade:4, gancho:"A hipótese mais influente e mais contestada da linguística do século XX." },
  { id:"mudanca-fonetica", termo:"Mudança fonética e leis regulares", area:"Linguística", dificuldade:3, gancho:"Línguas mudam com regularidade quase física — o que permite reconstruir idiomas mortos." },
  { id:"pidgin-crioulo", termo:"Pidgins e crioulos", area:"Linguística", dificuldade:3, gancho:"Línguas inteiras nascendo em uma geração, sob condições históricas brutais." },
  { id:"signo-saussure", termo:"Signo linguístico e arbitrariedade (Saussure)", area:"Linguística", dificuldade:2, gancho:"Não há nada de canino na palavra 'cão'. Dessa banalidade nasceu o estruturalismo." },
  { id:"atos-de-fala", termo:"Atos de fala (Austin e Searle)", area:"Linguística", dificuldade:3, gancho:"Dizer 'eu aceito' num casamento não descreve nada: faz algo acontecer." },
  { id:"lei-zipf", termo:"Lei de Zipf e estatística das línguas", area:"Linguística", dificuldade:3, gancho:"A frequência das palavras segue uma regra matemática rígida em qualquer idioma." },
  { id:"escrita-sistemas", termo:"Sistemas de escrita: alfabeto, silabário, logografia", area:"Linguística", dificuldade:2, gancho:"Três soluções diferentes para representar fala com marcas — com custos cognitivos distintos." },

  /* ── Design e Arquitetura ─────────────────────────────────────────── */
  { id:"gestalt-design", termo:"Princípios da Gestalt no design visual", area:"Design", dificuldade:2, gancho:"Regras de percepção descobertas em 1920 que governam toda interface que você usa hoje." },
  { id:"affordances", termo:"Affordances e design de interação (Norman)", area:"Design", dificuldade:2, gancho:"Se o usuário errou, o objeto é que está mal projetado. Uma inversão radical de responsabilidade." },
  { id:"teoria-cor", termo:"Teoria da cor e contraste simultâneo", area:"Design", dificuldade:2, gancho:"A mesma cor parece diferente dependendo da vizinha. Sua retina não mede: compara." },
  { id:"tipografia-legibilidade", termo:"Tipografia e legibilidade", area:"Design", dificuldade:2, gancho:"Séculos de convenção tipográfica que quase nunca são testados empiricamente — e o que os testes dizem." },
  { id:"grid-editorial", termo:"Sistemas de grid e o estilo suíço", area:"Design", dificuldade:2, gancho:"Uma ideologia modernista disfarçada de método de diagramação." },
  { id:"design-sistemas", termo:"Design systems e consistência em escala", area:"Design", dificuldade:2, gancho:"Como manter coerência visual quando cem pessoas editam o mesmo produto." },
  { id:"acessibilidade", termo:"Acessibilidade e desenho universal", area:"Design", dificuldade:2, gancho:"Projetar para a margem costuma melhorar a experiência do centro. O meio-fio rebaixado é o caso clássico." },
  { id:"forma-funcao", termo:"'Forma segue função': origem e mal-entendidos", area:"Arquitetura", dificuldade:2, gancho:"A frase mais citada da arquitetura moderna quase sempre é citada errada." },
  { id:"bauhaus", termo:"Bauhaus: programa e legado", area:"Arquitetura", dificuldade:2, gancho:"Uma escola que durou 14 anos e definiu a aparência do século XX." },
  { id:"cidade-jacobs", termo:"Vitalidade urbana segundo Jane Jacobs", area:"Arquitetura", dificuldade:2, gancho:"Uma jornalista sem diploma demoliu o urbanismo modernista com observação de calçada." },
  { id:"conforto-termico", termo:"Arquitetura bioclimática e conforto térmico", area:"Arquitetura", dificuldade:3, gancho:"Resolver temperatura com geometria e material antes de resolver com energia." },
  { id:"espaco-publico", termo:"Espaço público e vida entre edifícios (Gehl)", area:"Arquitetura", dificuldade:2, gancho:"Medir cidades pela quantidade de gente parada, não pela quantidade de carros passando." },
  { id:"patrimonio-restauro", termo:"Teoria do restauro e autenticidade", area:"Arquitetura", dificuldade:3, gancho:"Restaurar até que estado? A pergunta divide conservadores há 150 anos." },

  /* ── Música e Artes ───────────────────────────────────────────────── */
  { id:"temperamento-igual", termo:"Temperamento igual: a matemática da afinação", area:"Música", dificuldade:3, gancho:"Todo piano do mundo está ligeiramente desafinado de propósito. A física não deixa alternativa." },
  { id:"harmonia-funcional", termo:"Harmonia funcional e tensão-resolução", area:"Música", dificuldade:3, gancho:"Por que certos acordes 'pedem' outros — uma gramática que você já domina sem saber." },
  { id:"timbre", termo:"Timbre e série harmônica", area:"Música", dificuldade:3, gancho:"O que faz um violino soar diferente de uma flauta tocando a mesma nota." },
  { id:"ritmo-metrica", termo:"Ritmo, métrica e síncope", area:"Música", dificuldade:2, gancho:"Groove é uma expectativa temporal violada com precisão." },
  { id:"serialismo", termo:"Atonalismo e serialismo", area:"Música", dificuldade:3, gancho:"Abolir o centro tonal deliberadamente — e o custo perceptivo dessa decisão." },
  { id:"musica-emocao", termo:"Por que música provoca emoção", area:"Música", dificuldade:3, gancho:"Hipóteses concorrentes, evidência parcial, e um problema científico ainda aberto." },
  { id:"perspectiva-renascimento", termo:"Perspectiva linear e a invenção do espaço pictórico", area:"Artes", dificuldade:2, gancho:"Uma técnica geométrica do século XV que reprogramou como o Ocidente vê imagens." },
  { id:"ready-made", termo:"Ready-made e a pergunta 'o que é arte?'", area:"Artes", dificuldade:2, gancho:"Um urinol em 1917 transferiu a definição de arte do objeto para a instituição." },
  { id:"narrativa-nao-linear", termo:"Estrutura narrativa e tempo na literatura", area:"Literatura", dificuldade:2, gancho:"Ordem, duração e frequência: as três alavancas de qualquer narrador." },
  { id:"realismo-magico", termo:"Realismo mágico: forma e contexto histórico", area:"Literatura", dificuldade:2, gancho:"Uma estética que só faz sentido inteiramente à luz da história latino-americana." },

  /* ── Marketing e Negócios ─────────────────────────────────────────── */
  { id:"posicionamento", termo:"Posicionamento de marca", area:"Marketing", dificuldade:2, gancho:"A disputa não é pelo produto melhor: é por um lugar vago na cabeça das pessoas." },
  { id:"mera-exposicao", termo:"Efeito de mera exposição", area:"Marketing", dificuldade:2, gancho:"Gostamos mais do que já vimos antes, mesmo sem lembrar de ter visto." },
  { id:"prova-social", termo:"Prova social e influência (Cialdini)", area:"Marketing", dificuldade:2, gancho:"Seis alavancas de persuasão documentadas — e quais delas sobreviveram à replicação." },
  { id:"precificacao-psicologica", termo:"Ancoragem e precificação psicológica", area:"Marketing", dificuldade:2, gancho:"O primeiro número que você vê contamina todos os julgamentos seguintes." },
  { id:"difusao-inovacao", termo:"Difusão de inovações (Rogers)", area:"Marketing", dificuldade:2, gancho:"A curva em S que descreve como qualquer novidade se espalha por uma população." },
  { id:"efeito-rede", termo:"Efeitos de rede e vantagem competitiva", area:"Negócios", dificuldade:2, gancho:"Produtos que ficam melhores quanto mais gente usa — e por isso viram monopólios." },
  { id:"inovacao-disruptiva", termo:"Inovação disruptiva (Christensen)", area:"Negócios", dificuldade:3, gancho:"Um termo brutalmente mal utilizado, com uma tese original bem mais estreita e testável." },
  { id:"cauda-longa", termo:"Cauda longa e distribuições de poder", area:"Negócios", dificuldade:2, gancho:"Uma tese de 2004 sobre nichos digitais — parcialmente confirmada, parcialmente desmentida." },
  { id:"branding-memoria", termo:"Disponibilidade mental e estruturas de memória", area:"Marketing", dificuldade:3, gancho:"A escola empírica que contesta boa parte do marketing tradicional com dados de painel." },
  { id:"metricas-vaidade", termo:"Métricas de vaidade e causalidade em negócios", area:"Negócios", dificuldade:3, gancho:"Números que sobem e não significam nada. Distinguir isso exige desenho experimental." },

  /* ── Nutrição e Saúde ─────────────────────────────────────────────── */
  { id:"indice-glicemico", termo:"Índice glicêmico e resposta metabólica", area:"Nutrição", dificuldade:3, gancho:"Um conceito útil, mal aplicado e frequentemente superestimado. Bom caso de leitura crítica." },
  { id:"epidemiologia-nutricional", termo:"Por que estudos de nutrição se contradizem", area:"Nutrição", dificuldade:3, gancho:"Limitações metodológicas estruturais que explicam a manchete de nutrição da semana." },
  { id:"proteina-necessidade", termo:"Necessidade proteica: evidência e exageros", area:"Nutrição", dificuldade:3, gancho:"Onde termina a fisiologia e começa o marketing de suplementos." },
  { id:"ultraprocessados", termo:"Alimentos ultraprocessados e a classificação NOVA", area:"Nutrição", dificuldade:3, gancho:"Uma classificação brasileira que virou referência global — e as críticas que ela recebe." },
  { id:"jejum-intermitente", termo:"Jejum intermitente: o que os ensaios mostram", area:"Nutrição", dificuldade:3, gancho:"Mecanismos plausíveis, resultados clínicos mais modestos do que a popularidade sugere." },
  { id:"vitamina-suplemento", termo:"Suplementação vitamínica: quando funciona", area:"Nutrição", dificuldade:2, gancho:"Deficiência real versus otimização especulativa — a diferença é grande." },
  { id:"balanco-energetico", termo:"Balanço energético e suas complicações", area:"Nutrição", dificuldade:3, gancho:"'Calorias que entram, calorias que saem' é verdade termodinâmica e péssimo conselho prático." },
  { id:"microbiota-dieta", termo:"Dieta e microbiota: evidência atual", area:"Nutrição", dificuldade:3, gancho:"Associações fortes, causalidade fraca, e uma indústria correndo na frente da ciência." },
  { id:"nnt-risco", termo:"NNT e risco relativo versus absoluto", area:"Medicina", dificuldade:3, gancho:"'Reduz o risco em 50%' pode significar quase nada. Aprender a ler isso muda decisões." },
  { id:"triagem-sobrediagnostico", termo:"Rastreamento e sobrediagnóstico", area:"Medicina", dificuldade:3, gancho:"Detectar mais cedo nem sempre salva vidas — às vezes só cria mais pacientes." },

  /* ── Computação e IA ──────────────────────────────────────────────── */
  { id:"p-np", termo:"P versus NP", area:"Computação", dificuldade:4, gancho:"Verificar uma resposta é mais fácil que encontrá-la? Vale um milhão de dólares descobrir." },
  { id:"criptografia-assimetrica", termo:"Criptografia de chave pública", area:"Computação", dificuldade:3, gancho:"Como duas pessoas que nunca se falaram combinam um segredo em público." },
  { id:"compressao-informacao", termo:"Entropia de Shannon e compressão", area:"Computação", dificuldade:3, gancho:"Existe um limite matemático exato para comprimir qualquer arquivo. Shannon calculou." },
  { id:"halting", termo:"Problema da parada e limites da computação", area:"Computação", dificuldade:4, gancho:"Há perguntas que nenhum computador jamais poderá responder. Provado em 1936." },
  { id:"transformers", termo:"Arquitetura Transformer e atenção", area:"IA", dificuldade:4, gancho:"O mecanismo que destravou os modelos de linguagem modernos, explicado sem hype." },
  { id:"overfitting", termo:"Sobreajuste e o dilema viés-variância", area:"IA", dificuldade:3, gancho:"Decorar não é aprender — e distinguir os dois é o problema central do aprendizado de máquina." },
  { id:"vies-algoritmico", termo:"Viés algorítmico e justiça estatística", area:"IA", dificuldade:3, gancho:"Definições formais de 'justo' que são matematicamente incompatíveis entre si." },
  { id:"blockchain", termo:"Blockchain e consenso distribuído", area:"Computação", dificuldade:3, gancho:"O problema real que ela resolve, e a lista bem menor de casos em que isso importa." },
  { id:"quantum-computing", termo:"Computação quântica: promessa e estado atual", area:"Computação", dificuldade:4, gancho:"O que ela realmente aceleraria, e a distância entre demonstração e utilidade." },
  { id:"reprodutibilidade-computacional", termo:"Reprodutibilidade computacional", area:"Computação", dificuldade:2, gancho:"Um resultado que ninguém consegue rodar de novo é resultado?" },

  /* ── Estatística e Método ─────────────────────────────────────────── */
  { id:"valor-p", termo:"O que o valor-p realmente significa", area:"Estatística", dificuldade:3, gancho:"A quantidade mais usada e mais mal interpretada da ciência empírica." },
  { id:"regressao-media", termo:"Regressão à média", area:"Estatística", dificuldade:2, gancho:"Um fenômeno puramente estatístico que gera ilusões de causalidade em medicina, esporte e gestão." },
  { id:"simpson-paradoxo", termo:"Paradoxo de Simpson", area:"Estatística", dificuldade:3, gancho:"A mesma base de dados apoiando conclusões opostas conforme você agrega ou separa." },
  { id:"causalidade-pearl", termo:"Inferência causal e a escada de Pearl", area:"Estatística", dificuldade:4, gancho:"Um formalismo que permite falar de causa sem constrangimento — e distinguir três níveis de pergunta." },
  { id:"amostragem-vies", termo:"Viés de seleção e sobrevivência", area:"Estatística", dificuldade:2, gancho:"Os aviões que voltaram do combate mostravam onde NÃO reforçar a blindagem." },
  { id:"poder-estatistico", termo:"Poder estatístico e estudos subdimensionados", area:"Estatística", dificuldade:3, gancho:"Estudos pequenos não só falham em detectar efeitos: eles exageram os que detectam." },
  { id:"bootstrap", termo:"Bootstrap e reamostragem", area:"Estatística", dificuldade:3, gancho:"Estimar incerteza reamostrando os próprios dados — uma ideia quase impertinente que funciona." },
  { id:"pre-registro", termo:"Pré-registro e graus de liberdade do pesquisador", area:"Estatística", dificuldade:2, gancho:"Decidir a análise antes de ver os dados. Simples, barato e transformador." }

];

if (typeof module !== "undefined") { module.exports = { CATALOGO }; }
